package PH;

public enum FahrzeugTyp {
    AUTO, MOTORRAD
}
