package PH;

public class Auto extends Fahrzeug {
    public Auto(String id) {
        super(id, FahrzeugTyp.AUTO);
    }
}