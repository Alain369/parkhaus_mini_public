package PH;

public class Motorrad extends Fahrzeug {
    public Motorrad(String id) {
        super(id, FahrzeugTyp.MOTORRAD);
    }
}
